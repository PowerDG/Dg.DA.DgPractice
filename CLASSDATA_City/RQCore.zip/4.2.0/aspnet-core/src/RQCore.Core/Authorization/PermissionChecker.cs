﻿using Abp.Authorization;
using RQCore.Authorization.Roles;
using RQCore.Authorization.Users;

namespace RQCore.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
