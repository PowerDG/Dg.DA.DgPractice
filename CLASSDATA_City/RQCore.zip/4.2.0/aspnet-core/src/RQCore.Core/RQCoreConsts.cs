﻿namespace RQCore
{
    public class RQCoreConsts
    {
        public const string LocalizationSourceName = "RQCore";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
