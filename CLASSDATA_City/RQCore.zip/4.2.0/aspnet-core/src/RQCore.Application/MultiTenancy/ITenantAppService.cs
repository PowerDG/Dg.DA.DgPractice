﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using RQCore.MultiTenancy.Dto;

namespace RQCore.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
