﻿using System.Threading.Tasks;
using RQCore.Configuration.Dto;

namespace RQCore.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
