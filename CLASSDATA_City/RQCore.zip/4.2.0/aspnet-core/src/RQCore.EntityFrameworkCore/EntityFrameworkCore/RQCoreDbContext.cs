﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using RQCore.Authorization.Roles;
using RQCore.Authorization.Users;
using RQCore.MultiTenancy;

namespace RQCore.EntityFrameworkCore
{
    public class RQCoreDbContext : AbpZeroDbContext<Tenant, Role, User, RQCoreDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public RQCoreDbContext(DbContextOptions<RQCoreDbContext> options)
            : base(options)
        {
        }
    }
}
