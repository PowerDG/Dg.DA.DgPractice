﻿using Abp.Configuration.Startup;
using Abp.Localization.Dictionaries;
using Abp.Localization.Dictionaries.Xml;
using Abp.Reflection.Extensions;

namespace RQTmsCore.Localization
{
    public static class RQTmsCoreLocalizationConfigurer
    {
        public static void Configure(ILocalizationConfiguration localizationConfiguration)
        {
            localizationConfiguration.Sources.Add(
                new DictionaryBasedLocalizationSource(RQTmsCoreConsts.LocalizationSourceName,
                    new XmlEmbeddedFileLocalizationDictionaryProvider(
                        typeof(RQTmsCoreLocalizationConfigurer).GetAssembly(),
                        "RQTmsCore.Localization.SourceFiles"
                    )
                )
            );
        }
    }
}
