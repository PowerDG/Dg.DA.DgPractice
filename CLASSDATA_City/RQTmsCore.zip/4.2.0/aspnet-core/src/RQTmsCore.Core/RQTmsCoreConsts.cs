﻿namespace RQTmsCore
{
    public class RQTmsCoreConsts
    {
        public const string LocalizationSourceName = "RQTmsCore";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
