﻿using Abp.Authorization;
using RQTmsCore.Authorization.Roles;
using RQTmsCore.Authorization.Users;

namespace RQTmsCore.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
