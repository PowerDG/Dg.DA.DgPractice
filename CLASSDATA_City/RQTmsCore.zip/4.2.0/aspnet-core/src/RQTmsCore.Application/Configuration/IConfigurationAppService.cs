﻿using System.Threading.Tasks;
using RQTmsCore.Configuration.Dto;

namespace RQTmsCore.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
