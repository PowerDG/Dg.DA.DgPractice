﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using RQTmsCore.Authorization;

namespace RQTmsCore
{
    [DependsOn(
        typeof(RQTmsCoreCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class RQTmsCoreApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<RQTmsCoreAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(RQTmsCoreApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddProfiles(thisAssembly)
            );
        }
    }
}
