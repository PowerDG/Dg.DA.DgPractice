﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RQTmsCore.Sessions.Dto;

namespace RQTmsCore.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
