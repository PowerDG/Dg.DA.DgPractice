﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using RQTmsCore.MultiTenancy.Dto;

namespace RQTmsCore.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
