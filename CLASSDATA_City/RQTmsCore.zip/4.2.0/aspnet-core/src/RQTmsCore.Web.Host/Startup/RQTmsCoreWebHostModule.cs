﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using RQTmsCore.Configuration;

namespace RQTmsCore.Web.Host.Startup
{
    [DependsOn(
       typeof(RQTmsCoreWebCoreModule))]
    public class RQTmsCoreWebHostModule: AbpModule
    {
        private readonly IHostingEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public RQTmsCoreWebHostModule(IHostingEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(RQTmsCoreWebHostModule).GetAssembly());
        }
    }
}
