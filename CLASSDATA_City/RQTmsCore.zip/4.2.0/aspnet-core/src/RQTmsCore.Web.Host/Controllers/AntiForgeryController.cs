using Microsoft.AspNetCore.Antiforgery;
using RQTmsCore.Controllers;

namespace RQTmsCore.Web.Host.Controllers
{
    public class AntiForgeryController : RQTmsCoreControllerBase
    {
        private readonly IAntiforgery _antiforgery;

        public AntiForgeryController(IAntiforgery antiforgery)
        {
            _antiforgery = antiforgery;
        }

        public void GetToken()
        {
            _antiforgery.SetCookieTokenAndHeader(HttpContext);
        }
    }
}
