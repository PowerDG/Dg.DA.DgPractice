﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using RQTmsCore.Configuration;
using RQTmsCore.Web;

namespace RQTmsCore.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class RQTmsCoreDbContextFactory : IDesignTimeDbContextFactory<RQTmsCoreDbContext>
    {
        public RQTmsCoreDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<RQTmsCoreDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            RQTmsCoreDbContextConfigurer.Configure(builder, configuration.GetConnectionString(RQTmsCoreConsts.ConnectionStringName));

            return new RQTmsCoreDbContext(builder.Options);
        }
    }
}
