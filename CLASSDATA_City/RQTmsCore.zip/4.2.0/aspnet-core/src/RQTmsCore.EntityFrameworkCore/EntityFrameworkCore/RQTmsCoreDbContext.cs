﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using RQTmsCore.Authorization.Roles;
using RQTmsCore.Authorization.Users;
using RQTmsCore.MultiTenancy;

namespace RQTmsCore.EntityFrameworkCore
{
    public class RQTmsCoreDbContext : AbpZeroDbContext<Tenant, Role, User, RQTmsCoreDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public RQTmsCoreDbContext(DbContextOptions<RQTmsCoreDbContext> options)
            : base(options)
        {
        }
    }
}
