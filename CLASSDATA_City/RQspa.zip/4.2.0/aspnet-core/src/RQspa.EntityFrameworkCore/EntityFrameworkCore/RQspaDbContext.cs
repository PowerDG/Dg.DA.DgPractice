﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using RQspa.Authorization.Roles;
using RQspa.Authorization.Users;
using RQspa.MultiTenancy;

namespace RQspa.EntityFrameworkCore
{
    public class RQspaDbContext : AbpZeroDbContext<Tenant, Role, User, RQspaDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public RQspaDbContext(DbContextOptions<RQspaDbContext> options)
            : base(options)
        {
        }
    }
}
