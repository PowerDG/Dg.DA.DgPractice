using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace RQspa.EntityFrameworkCore
{
    public static class RQspaDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<RQspaDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<RQspaDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
