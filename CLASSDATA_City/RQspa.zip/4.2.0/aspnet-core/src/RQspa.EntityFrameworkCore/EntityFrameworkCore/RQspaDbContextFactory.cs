﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using RQspa.Configuration;
using RQspa.Web;

namespace RQspa.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class RQspaDbContextFactory : IDesignTimeDbContextFactory<RQspaDbContext>
    {
        public RQspaDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<RQspaDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            RQspaDbContextConfigurer.Configure(builder, configuration.GetConnectionString(RQspaConsts.ConnectionStringName));

            return new RQspaDbContext(builder.Options);
        }
    }
}
