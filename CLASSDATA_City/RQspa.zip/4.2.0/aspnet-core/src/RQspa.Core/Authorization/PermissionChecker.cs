﻿using Abp.Authorization;
using RQspa.Authorization.Roles;
using RQspa.Authorization.Users;

namespace RQspa.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
