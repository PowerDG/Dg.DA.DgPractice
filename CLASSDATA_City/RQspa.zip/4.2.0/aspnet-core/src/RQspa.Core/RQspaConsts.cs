﻿namespace RQspa
{
    public class RQspaConsts
    {
        public const string LocalizationSourceName = "RQspa";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
