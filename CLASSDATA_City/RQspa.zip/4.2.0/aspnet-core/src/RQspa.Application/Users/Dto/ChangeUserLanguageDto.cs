using System.ComponentModel.DataAnnotations;

namespace RQspa.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}