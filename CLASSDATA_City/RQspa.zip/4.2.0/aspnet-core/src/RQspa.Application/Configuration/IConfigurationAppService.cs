﻿using System.Threading.Tasks;
using RQspa.Configuration.Dto;

namespace RQspa.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
