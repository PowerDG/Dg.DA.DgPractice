﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RQspa.Authorization.Accounts.Dto;

namespace RQspa.Authorization.Accounts
{
    public interface IAccountAppService : IApplicationService
    {
        Task<IsTenantAvailableOutput> IsTenantAvailable(IsTenantAvailableInput input);

        Task<RegisterOutput> Register(RegisterInput input);
    }
}
