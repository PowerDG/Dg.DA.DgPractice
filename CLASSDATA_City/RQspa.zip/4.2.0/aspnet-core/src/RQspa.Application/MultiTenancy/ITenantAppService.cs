﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using RQspa.MultiTenancy.Dto;

namespace RQspa.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
