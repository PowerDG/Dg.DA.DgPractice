﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RQspa.Sessions.Dto;

namespace RQspa.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
