﻿using Abp.AspNetCore.Mvc.ViewComponents;

namespace RQMCore.Web.Views
{
    public abstract class RQMCoreViewComponent : AbpViewComponent
    {
        protected RQMCoreViewComponent()
        {
            LocalizationSourceName = RQMCoreConsts.LocalizationSourceName;
        }
    }
}
