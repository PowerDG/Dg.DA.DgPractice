﻿using Microsoft.AspNetCore.Mvc.Razor.Internal;
using Abp.AspNetCore.Mvc.Views;
using Abp.Runtime.Session;

namespace RQMCore.Web.Views
{
    public abstract class RQMCoreRazorPage<TModel> : AbpRazorPage<TModel>
    {
        [RazorInject]
        public IAbpSession AbpSession { get; set; }

        protected RQMCoreRazorPage()
        {
            LocalizationSourceName = RQMCoreConsts.LocalizationSourceName;
        }
    }
}
