﻿using Microsoft.AspNetCore.Mvc;
using Abp.AspNetCore.Mvc.Authorization;
using RQMCore.Controllers;

namespace RQMCore.Web.Controllers
{
    [AbpMvcAuthorize]
    public class AboutController : RQMCoreControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}
