﻿using Abp.Authorization;
using RQMCore.Authorization.Roles;
using RQMCore.Authorization.Users;

namespace RQMCore.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
