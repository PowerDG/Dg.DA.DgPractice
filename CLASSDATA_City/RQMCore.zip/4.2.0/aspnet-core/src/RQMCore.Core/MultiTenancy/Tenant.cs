﻿using Abp.MultiTenancy;
using RQMCore.Authorization.Users;

namespace RQMCore.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
