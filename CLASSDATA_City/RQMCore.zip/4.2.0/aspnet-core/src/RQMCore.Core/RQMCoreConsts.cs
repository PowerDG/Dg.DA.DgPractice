﻿namespace RQMCore
{
    public class RQMCoreConsts
    {
        public const string LocalizationSourceName = "RQMCore";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
