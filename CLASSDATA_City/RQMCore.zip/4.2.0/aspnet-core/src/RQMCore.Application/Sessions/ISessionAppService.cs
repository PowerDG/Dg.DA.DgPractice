﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RQMCore.Sessions.Dto;

namespace RQMCore.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
