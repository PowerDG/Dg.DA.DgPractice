using System.ComponentModel.DataAnnotations;

namespace RQMCore.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}