﻿using System.Threading.Tasks;
using RQMCore.Configuration.Dto;

namespace RQMCore.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
