﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using RQMCore.Configuration.Dto;

namespace RQMCore.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : RQMCoreAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
