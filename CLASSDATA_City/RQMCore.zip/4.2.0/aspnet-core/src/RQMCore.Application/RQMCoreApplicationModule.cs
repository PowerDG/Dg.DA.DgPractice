﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using RQMCore.Authorization;

namespace RQMCore
{
    [DependsOn(
        typeof(RQMCoreCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class RQMCoreApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<RQMCoreAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(RQMCoreApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddProfiles(thisAssembly)
            );
        }
    }
}
