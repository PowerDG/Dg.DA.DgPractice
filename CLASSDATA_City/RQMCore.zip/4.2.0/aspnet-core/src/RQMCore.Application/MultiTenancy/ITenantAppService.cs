﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using RQMCore.MultiTenancy.Dto;

namespace RQMCore.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
