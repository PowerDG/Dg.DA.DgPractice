﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using RQMCore.Authorization.Roles;
using RQMCore.Authorization.Users;
using RQMCore.MultiTenancy;

namespace RQMCore.EntityFrameworkCore
{
    public class RQMCoreDbContext : AbpZeroDbContext<Tenant, Role, User, RQMCoreDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public RQMCoreDbContext(DbContextOptions<RQMCoreDbContext> options)
            : base(options)
        {
        }
    }
}
