﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using RQMCore.Configuration;
using RQMCore.Web;

namespace RQMCore.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class RQMCoreDbContextFactory : IDesignTimeDbContextFactory<RQMCoreDbContext>
    {
        public RQMCoreDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<RQMCoreDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            RQMCoreDbContextConfigurer.Configure(builder, configuration.GetConnectionString(RQMCoreConsts.ConnectionStringName));

            return new RQMCoreDbContext(builder.Options);
        }
    }
}
