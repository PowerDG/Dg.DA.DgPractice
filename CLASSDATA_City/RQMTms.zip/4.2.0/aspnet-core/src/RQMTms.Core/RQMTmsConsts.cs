﻿namespace RQMTms
{
    public class RQMTmsConsts
    {
        public const string LocalizationSourceName = "RQMTms";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
