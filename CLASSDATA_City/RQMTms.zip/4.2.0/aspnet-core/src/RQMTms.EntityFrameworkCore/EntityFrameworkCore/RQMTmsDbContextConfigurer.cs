using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace RQMTms.EntityFrameworkCore
{
    public static class RQMTmsDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<RQMTmsDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<RQMTmsDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
