﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using RQMTms.Configuration;
using RQMTms.Web;

namespace RQMTms.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class RQMTmsDbContextFactory : IDesignTimeDbContextFactory<RQMTmsDbContext>
    {
        public RQMTmsDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<RQMTmsDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            RQMTmsDbContextConfigurer.Configure(builder, configuration.GetConnectionString(RQMTmsConsts.ConnectionStringName));

            return new RQMTmsDbContext(builder.Options);
        }
    }
}
