﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using RQMTms.Authorization.Roles;
using RQMTms.Authorization.Users;
using RQMTms.MultiTenancy;

namespace RQMTms.EntityFrameworkCore
{
    public class RQMTmsDbContext : AbpZeroDbContext<Tenant, Role, User, RQMTmsDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public RQMTmsDbContext(DbContextOptions<RQMTmsDbContext> options)
            : base(options)
        {
        }
    }
}
