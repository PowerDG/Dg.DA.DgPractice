﻿using System.Collections.Generic;
using RQMTms.Roles.Dto;

namespace RQMTms.Web.Models.Roles
{
    public class RoleListViewModel
    {
        public IReadOnlyList<RoleListDto> Roles { get; set; }

        public IReadOnlyList<PermissionDto> Permissions { get; set; }
    }
}
