﻿using System.Collections.Generic;
using RQMTms.Roles.Dto;

namespace RQMTms.Web.Models.Common
{
    public interface IPermissionsEditViewModel
    {
        List<FlatPermissionDto> Permissions { get; set; }
    }
}