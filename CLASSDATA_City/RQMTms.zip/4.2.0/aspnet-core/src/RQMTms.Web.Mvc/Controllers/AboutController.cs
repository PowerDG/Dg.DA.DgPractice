﻿using Microsoft.AspNetCore.Mvc;
using Abp.AspNetCore.Mvc.Authorization;
using RQMTms.Controllers;

namespace RQMTms.Web.Controllers
{
    [AbpMvcAuthorize]
    public class AboutController : RQMTmsControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}
