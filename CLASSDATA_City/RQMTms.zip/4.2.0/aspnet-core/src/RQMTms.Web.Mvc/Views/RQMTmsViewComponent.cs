﻿using Abp.AspNetCore.Mvc.ViewComponents;

namespace RQMTms.Web.Views
{
    public abstract class RQMTmsViewComponent : AbpViewComponent
    {
        protected RQMTmsViewComponent()
        {
            LocalizationSourceName = RQMTmsConsts.LocalizationSourceName;
        }
    }
}
