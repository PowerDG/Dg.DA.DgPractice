﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using RQMTms.Configuration;

namespace RQMTms.Web.Host.Startup
{
    [DependsOn(
       typeof(RQMTmsWebCoreModule))]
    public class RQMTmsWebHostModule: AbpModule
    {
        private readonly IHostingEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public RQMTmsWebHostModule(IHostingEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(RQMTmsWebHostModule).GetAssembly());
        }
    }
}
