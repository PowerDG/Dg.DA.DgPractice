using Abp.AspNetCore.Mvc.Controllers;
using Abp.IdentityFramework;
using Microsoft.AspNetCore.Identity;

namespace RQMTms.Controllers
{
    public abstract class RQMTmsControllerBase: AbpController
    {
        protected RQMTmsControllerBase()
        {
            LocalizationSourceName = RQMTmsConsts.LocalizationSourceName;
        }

        protected void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}
