﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RQMTms.Authorization.Accounts.Dto;

namespace RQMTms.Authorization.Accounts
{
    public interface IAccountAppService : IApplicationService
    {
        Task<IsTenantAvailableOutput> IsTenantAvailable(IsTenantAvailableInput input);

        Task<RegisterOutput> Register(RegisterInput input);
    }
}
