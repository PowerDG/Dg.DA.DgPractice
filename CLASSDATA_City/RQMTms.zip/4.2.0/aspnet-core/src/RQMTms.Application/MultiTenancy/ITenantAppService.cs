﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using RQMTms.MultiTenancy.Dto;

namespace RQMTms.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
