﻿using System.Threading.Tasks;
using RQMTms.Configuration.Dto;

namespace RQMTms.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
